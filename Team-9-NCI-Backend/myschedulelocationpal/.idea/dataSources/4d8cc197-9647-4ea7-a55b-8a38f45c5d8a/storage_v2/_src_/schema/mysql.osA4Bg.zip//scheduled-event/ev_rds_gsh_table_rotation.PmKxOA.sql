create definer = rdsadmin@localhost event ev_rds_gsh_table_rotation on schedule
    every '7' DAY
        starts '2026-02-25 17:01:38'
    on completion preserve
    disable
    do
    CALL rds_rotate_global_status_history();

