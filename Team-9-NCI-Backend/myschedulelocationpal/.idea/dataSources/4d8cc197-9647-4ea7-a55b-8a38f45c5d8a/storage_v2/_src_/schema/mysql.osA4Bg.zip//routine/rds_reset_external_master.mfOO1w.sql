create
    definer = rdsadmin@localhost procedure rds_reset_external_master()
BEGIN
  SELECT 'mysql.rds_reset_external_master is deprecated and will be removed in a future release. Use mysql.rds_reset_external_source instead. Refer to the documentation for more information on deprecated statements' AS Message;
  CALL mysql.rds_reset_external_source();
END;

